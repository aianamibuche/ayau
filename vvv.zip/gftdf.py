# 1 Задание
string = "hello world"
print(string.upper())          
print(string[:3])              

# 2 Задание 
tuple_example = (1, 2, 3, 4, 5)
print(tuple_example[1:3])      

# 3 Задание
string_list = ["banana", "apple", "cherry"]
string_list.sort()             
print(string_list)

# 4 Задание
mixed_list = [1, "hello", 3.14, True]
print(len(mixed_list))         

# 5 Задание
sentence = "this is a simple sentence"
words = sentence.split()       
print(words)

# 6 Задание
numbers = [10, 20, 5, 40, 15]
print(max(numbers))            

# 7 Задание
words_list = ["apple", "banana", "cherry"]
joined_string = ",".join(words_list)  
print(joined_string)